package za.ac.cput;

/**
 * Created by Mvuyisi Jezile on 2016/09/02.
 */
public class RegisterVehicle {
    public static abstract class NewVehicleInfo
    {
        public static final String REG_NO = "registration_no";
        public static final String VEHICLE_NAME = "vehivle_name";
        public static final String MODEL = "model";
        public static final String YEAR = "year";
        public static final String TABLE_NAME = "vehicle_info";
    }
}
