package za.ac.cput.vehicleserviceassistant;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import za.ac.cput.AddVehicle;
import za.ac.cput.ViewVehicle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void clickAddVehicle(View view)
    {
        Intent intent = new Intent(this, AddVehicle.class);
        startActivity(intent);
    }

    public void viewVehicles(View view)
    {
        Intent intent = new Intent(this, ViewVehicle.class);
        startActivity(intent);
    }
}
