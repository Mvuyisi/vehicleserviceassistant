package za.ac.cput;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by Mvuyisi Jezile on 2016/09/02.
 */
public class VehicleDbHelper  extends SQLiteOpenHelper {
    private static final String VEHICLE_DB = "VEHICLEINFO.DB";
    private static final int DATABASE_VERSION = 1;
    private static final String CREATE_QUERY =
            "CREATE TABLE "+ RegisterVehicle.NewVehicleInfo.TABLE_NAME+"("+ RegisterVehicle.NewVehicleInfo.REG_NO+" TEXT,"+
                    RegisterVehicle.NewVehicleInfo.VEHICLE_NAME+" TEXT,"+RegisterVehicle.NewVehicleInfo.MODEL+" TEXT,"+
                    RegisterVehicle.NewVehicleInfo.YEAR+" TEXT);";
    public VehicleDbHelper(Context context)
    {
        super(context, VEHICLE_DB, null, DATABASE_VERSION);
        Log.e("DATABASE OPERATIONS", "Database created / opened...");
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_QUERY);
        Log.e("DATABASE OPERATIONS", "Table created...");
    }

    public void registerVehicle(String reg_no, String name, String model, String year, SQLiteDatabase db)
    {
        ContentValues contentValues = new ContentValues();
        contentValues.put(RegisterVehicle.NewVehicleInfo.REG_NO, reg_no);
        contentValues.put(RegisterVehicle.NewVehicleInfo.VEHICLE_NAME, name);
        contentValues.put(RegisterVehicle.NewVehicleInfo.MODEL, model);
        contentValues.put(RegisterVehicle.NewVehicleInfo.YEAR, year);
        db.insert(RegisterVehicle.NewVehicleInfo.TABLE_NAME, null, contentValues);
        Log.e("DATABASE OPERATIONS", "Vehicle registered...");
    }

    public Cursor getVehicle(SQLiteDatabase db)
    {
        Cursor vehicle_cur;
        String[] projections = {RegisterVehicle.NewVehicleInfo.REG_NO, RegisterVehicle.NewVehicleInfo.VEHICLE_NAME,
                RegisterVehicle.NewVehicleInfo.MODEL, RegisterVehicle.NewVehicleInfo.YEAR};
        vehicle_cur = db.query(RegisterVehicle.NewVehicleInfo.TABLE_NAME, projections, null, null, null, null, null);
        return vehicle_cur;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
