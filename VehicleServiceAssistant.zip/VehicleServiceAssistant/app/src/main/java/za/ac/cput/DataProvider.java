package za.ac.cput;

/**
 * Created by Mvuyisi Jezile on 2016/09/02.
 */
public class DataProvider {
    private String reg_no;
    private String name;
    private String model;
    private String year;

    public DataProvider(String reg_no, String name, String model, String year) {
        this.reg_no = reg_no;
        this.name = name;
        this.model = model;
        this.year = year;
    }

    public String getReg_no() {
        return reg_no;
    }

    public void setReg_no(String reg_no) {
        this.reg_no = reg_no;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }
}
