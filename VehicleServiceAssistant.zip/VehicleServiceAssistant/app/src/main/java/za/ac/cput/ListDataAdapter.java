package za.ac.cput;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import za.ac.cput.vehicleserviceassistant.R;

/**
 * Created by Mvuyisi Jezile on 2016/09/02.
 */
public class ListDataAdapter extends ArrayAdapter {
    List list = new ArrayList();
    public ListDataAdapter(Context context, int resource) {
        super(context, resource);
    }

    static class LayoutHandler
    {
        TextView REG_NO, NAME, MODEL, YEAR;
    }

    @Override
    public  void add(Object object)
    {
        super.add(object);
        list.add(object);
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        LayoutHandler layoutHandler;
        if(row == null)
        {
            LayoutInflater layoutInflater = (LayoutInflater) this.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = layoutInflater.inflate(R.layout.rowlayout,parent,false);
            layoutHandler = new LayoutHandler();
            layoutHandler.REG_NO = (TextView)row.findViewById(R.id.text_reg_no);
            layoutHandler.NAME = (TextView)row.findViewById(R.id.text_vehicle_name);
            layoutHandler.MODEL = (TextView)row.findViewById(R.id.text_vehicle_model);
            layoutHandler.YEAR = (TextView)row.findViewById(R.id.text_vehicle_year);
            row.setTag(layoutHandler);
        }
        else
        {
            layoutHandler = (LayoutHandler) row.getTag();
        }
        DataProvider dataProvider = (DataProvider)this.getItem(position);
        layoutHandler.REG_NO.setText(dataProvider.getReg_no());
        layoutHandler.NAME.setText(dataProvider.getName());
        layoutHandler.MODEL.setText(dataProvider.getModel());
        layoutHandler.YEAR.setText(dataProvider.getYear());

        return row;
    }
}
