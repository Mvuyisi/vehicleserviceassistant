package za.ac.cput;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import za.ac.cput.vehicleserviceassistant.R;

public class ViewVehicle extends AppCompatActivity {

    ListView listView;
    SQLiteDatabase sqLiteDatabase;
    VehicleDbHelper vehicleDbHelper;
    Cursor vehicle_curr;
    ListDataAdapter listDataAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_vehicle);
        listView = (ListView)findViewById(R.id.listView);
        listDataAdapter = new ListDataAdapter(getApplicationContext(), R.layout.rowlayout);
        listView.setAdapter(listDataAdapter);
        vehicleDbHelper = new VehicleDbHelper(getApplicationContext());
        sqLiteDatabase = vehicleDbHelper.getReadableDatabase();
        vehicle_curr = vehicleDbHelper.getVehicle(sqLiteDatabase);
        if(vehicle_curr.moveToFirst())
        {
            do{
                String reg_no, name, model, year;
                reg_no = vehicle_curr.getString(0);
                name = vehicle_curr.getString(1);
                model = vehicle_curr.getString(2);
                year = vehicle_curr.getString(3);
                DataProvider dataProvider = new DataProvider(reg_no, name, model, year);
                listDataAdapter.add(dataProvider);
            }while (vehicle_curr.moveToNext());
        }
    }
}
