package za.ac.cput;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import za.ac.cput.vehicleserviceassistant.R;

public class AddVehicle extends AppCompatActivity {

    EditText Reg_No, Vehicle_Name, Vehicle_Model, Vehicle_Year;
    Context context = this;
    VehicleDbHelper vehicleDbHelper;
    SQLiteDatabase sqLiteDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_vehicle);
        Reg_No = (EditText) findViewById(R.id.txRegNo);
        Vehicle_Name = (EditText) findViewById(R.id.txtName);
        Vehicle_Model = (EditText) findViewById(R.id.txtModel);
        Vehicle_Year = (EditText) findViewById(R.id.txtYear);
    }

    public  void addVehicle(View view)
    {
        String reg_no = Reg_No.getText().toString();
        String name = Vehicle_Name.getText().toString();
        String model = Vehicle_Model.getText().toString();
        String year = Vehicle_Year.getText().toString();

        if(reg_no.equals(""))
        {
            Reg_No.requestFocus();
            Reg_No.setError("Enter Registration No!");
        } else if(name.equals(""))
        {
            Vehicle_Name.requestFocus();
            Vehicle_Name.setError("Enter Registration No!");
        }else if(model.equals(""))
        {
            Vehicle_Model.requestFocus();
            Vehicle_Model.setError("Enter Registration No!");
        } else if(year.equals(""))
        {
            Vehicle_Year.requestFocus();
            Vehicle_Year.setError("Enter Registration No!");
        }else {

            vehicleDbHelper = new VehicleDbHelper(context);
            sqLiteDatabase = vehicleDbHelper.getWritableDatabase();
            vehicleDbHelper.registerVehicle(reg_no, name, model, year, sqLiteDatabase);
            Toast.makeText(getBaseContext(), "Data Saved!", Toast.LENGTH_LONG).show();
            vehicleDbHelper.close();

            Reg_No.setText("");
            Vehicle_Name.setText("");
            Vehicle_Model.setText("");
            Vehicle_Year.setText("");
        }
    }
}
